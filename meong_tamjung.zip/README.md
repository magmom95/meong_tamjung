# meong_tamjung

### 1. USECASE 
<img src="https://user-images.githubusercontent.com/84279479/125884232-8e3cb9c2-c15f-41fa-9cbd-3ce7c60c81f4.png" width="600">

### 2. ERD
<img src="https://github.com/sonyujin95/meong_tamjung/blob/main/images/ERD%20-v1.png?raw=true" width="600">
